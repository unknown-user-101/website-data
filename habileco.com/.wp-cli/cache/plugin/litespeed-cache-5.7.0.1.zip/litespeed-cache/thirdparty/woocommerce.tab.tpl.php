<?php defined( 'WPINC' ) || exit ; ?>

<a class='litespeed-tab nav-tab' href='#woocommerce' data-litespeed-tab='woocommerce'><?php echo __( 'WooCommerce', 'litespeed-cache' ) ; ?></a>
